package com.example.fitrition.entities;

import android.os.Bundle;

public interface ViewFacilitiesActivity {
    public void onCreate(Bundle savedInstanceState);

}
